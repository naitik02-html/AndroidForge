package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Priority
import com.example.data.model.SlotType
import com.example.data.model.TimetableSlot
import com.example.data.repository.LearnixRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Learnix", appName)
  }

  @Test
  fun `test timetable slot addition in repository`() {
    val repo = LearnixRepository()
    val slot = TimetableSlot(
      id = UUID.randomUUID().toString(),
      dayOfWeek = 1,
      startTime = "08:00 AM",
      endTime = "09:30 AM",
      subjectName = "Physics",
      room = "Hall A",
      slotType = SlotType.LECTURE
    )
    repo.addTimetableSlot(slot)
    assertTrue(repo.timetableSlots.value.any { it.subjectName == "Physics" && it.room == "Hall A" })
  }

  @Test
  fun `test assignment toggle completion`() {
    val repo = LearnixRepository()
    val initialPending = repo.assignments.value.first { !it.isCompleted }
    repo.toggleAssignmentCompleted(initialPending.id)
    val updated = repo.assignments.value.first { it.id == initialPending.id }
    assertTrue(updated.isCompleted)
  }

  @Test
  fun `test notes repository creation`() {
    val repo = LearnixRepository()
    repo.addNote("Calculus Formulas", "Mathematics", "Integral of sin(x) is -cos(x)")
    assertTrue(repo.notes.value.any { it.title == "Calculus Formulas" })
  }
}
