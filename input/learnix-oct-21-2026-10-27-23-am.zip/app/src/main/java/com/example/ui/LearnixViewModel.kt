package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.LearnixRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

enum class LearnixScreen(val title: String) {
    HOME("Home"),
    TIMETABLE("Timetable"),
    TASKS("Homework"),
    NOTES("Notes"),
    QUIZ("Practice"),
    FOCUS("Focus Timer"),
    PROGRESS("Analytics")
}

enum class AssignmentFilter(val label: String) {
    ALL("All"),
    PENDING("Pending"),
    COMPLETED("Completed"),
    HIGH_PRIORITY("High Priority")
}

class LearnixViewModel(
    private val repository: LearnixRepository = LearnixRepository()
) : ViewModel() {

    // Current Screen
    private val _currentScreen = MutableStateFlow(LearnixScreen.HOME)
    val currentScreen: StateFlow<LearnixScreen> = _currentScreen.asStateFlow()

    fun navigateTo(screen: LearnixScreen) {
        _currentScreen.value = screen
    }

    // Repository Flows
    val timetableSlots = repository.timetableSlots
    val assignments = repository.assignments
    val notes = repository.notes
    val quizQuestions = repository.quizQuestions
    val quizHistory = repository.quizHistory
    val focusSessions = repository.focusSessions
    val studentStats = repository.studentStats
    val studyReminderEnabled = repository.studyReminderEnabled
    val studyReminderTime = repository.studyReminderTime

    // Notification message banner
    private val _bannerMessage = MutableStateFlow<String?>(null)
    val bannerMessage: StateFlow<String?> = _bannerMessage.asStateFlow()

    fun showBanner(message: String) {
        _bannerMessage.value = message
        viewModelScope.launch {
            delay(3500)
            if (_bannerMessage.value == message) {
                _bannerMessage.value = null
            }
        }
    }

    fun dismissBanner() {
        _bannerMessage.value = null
    }

    // --- TIMETABLE STATE ---
    private val _selectedDayOfWeek = MutableStateFlow(1) // Monday by default
    val selectedDayOfWeek: StateFlow<Int> = _selectedDayOfWeek.asStateFlow()

    fun setSelectedDayOfWeek(day: Int) {
        _selectedDayOfWeek.value = day
    }

    fun addTimetableSlot(
        dayOfWeek: Int,
        startTime: String,
        endTime: String,
        subjectName: String,
        room: String,
        instructor: String,
        slotType: SlotType
    ) {
        val slot = TimetableSlot(
            id = UUID.randomUUID().toString(),
            dayOfWeek = dayOfWeek,
            startTime = startTime,
            endTime = endTime,
            subjectName = subjectName,
            room = room,
            instructor = instructor,
            slotType = slotType
        )
        repository.addTimetableSlot(slot)
        showBanner("Scheduled $subjectName for ${getDayName(dayOfWeek)}!")
    }

    fun deleteTimetableSlot(id: String) {
        repository.deleteTimetableSlot(id)
        showBanner("Class removed from timetable.")
    }

    private fun getDayName(day: Int): String {
        return when (day) {
            1 -> "Monday"
            2 -> "Tuesday"
            3 -> "Wednesday"
            4 -> "Thursday"
            5 -> "Friday"
            6 -> "Saturday"
            else -> "Sunday"
        }
    }

    // --- ASSIGNMENTS STATE ---
    private val _selectedAssignmentFilter = MutableStateFlow(AssignmentFilter.ALL)
    val selectedAssignmentFilter: StateFlow<AssignmentFilter> = _selectedAssignmentFilter.asStateFlow()

    fun setAssignmentFilter(filter: AssignmentFilter) {
        _selectedAssignmentFilter.value = filter
    }

    fun toggleAssignmentCompleted(id: String) {
        val item = assignments.value.find { it.id == id }
        repository.toggleAssignmentCompleted(id)
        if (item != null && !item.isCompleted) {
            showBanner("🎉 Awesome job! Assignment completed!")
        }
    }

    fun addAssignment(
        title: String,
        subjectName: String,
        dueDate: String,
        priority: Priority,
        notes: String
    ) {
        val assignment = Assignment(
            id = UUID.randomUUID().toString(),
            title = title,
            subjectName = subjectName,
            dueDate = dueDate,
            daysRemaining = 2,
            priority = priority,
            isCompleted = false,
            notes = notes
        )
        repository.addAssignment(assignment)
        showBanner("Assignment '$title' added!")
    }

    fun deleteAssignment(id: String) {
        repository.deleteAssignment(id)
        showBanner("Assignment deleted.")
    }

    // --- NOTES STATE ---
    private val _notesSearchQuery = MutableStateFlow("")
    val notesSearchQuery: StateFlow<String> = _notesSearchQuery.asStateFlow()

    private val _selectedNoteSubject = MutableStateFlow<String?>("All")
    val selectedNoteSubject: StateFlow<String?> = _selectedNoteSubject.asStateFlow()

    fun setNotesSearchQuery(query: String) {
        _notesSearchQuery.value = query
    }

    fun setSelectedNoteSubject(subject: String?) {
        _selectedNoteSubject.value = subject
    }

    fun addNote(title: String, subjectName: String, content: String) {
        repository.addNote(title, subjectName, content)
        showBanner("Note '$title' saved!")
    }

    fun updateNote(id: String, title: String, subjectName: String, content: String) {
        repository.updateNote(id, title, subjectName, content)
        showBanner("Note updated!")
    }

    fun togglePinNote(id: String) {
        repository.togglePinNote(id)
    }

    fun deleteNote(id: String) {
        repository.deleteNote(id)
        showBanner("Note removed.")
    }

    // --- QUIZ PRACTICE STATE ---
    private val _activeQuizSubject = MutableStateFlow<String?>("Computer Science")
    val activeQuizSubject: StateFlow<String?> = _activeQuizSubject.asStateFlow()

    private val _quizQuestionIndex = MutableStateFlow(0)
    val quizQuestionIndex: StateFlow<Int> = _quizQuestionIndex.asStateFlow()

    private val _selectedOption = MutableStateFlow<Int?>(null)
    val selectedOption: StateFlow<Int?> = _selectedOption.asStateFlow()

    private val _isAnswerRevealed = MutableStateFlow(false)
    val isAnswerRevealed: StateFlow<Boolean> = _isAnswerRevealed.asStateFlow()

    private val _currentQuizScore = MutableStateFlow(0)
    val currentQuizScore: StateFlow<Int> = _currentQuizScore.asStateFlow()

    private val _isQuizCompleted = MutableStateFlow(false)
    val isQuizCompleted: StateFlow<Boolean> = _isQuizCompleted.asStateFlow()

    fun selectQuizSubject(subject: String) {
        _activeQuizSubject.value = subject
        resetQuiz()
    }

    fun selectOption(index: Int) {
        if (!_isAnswerRevealed.value) {
            _selectedOption.value = index
        }
    }

    fun submitAnswer(correctIndex: Int) {
        if (_selectedOption.value != null && !_isAnswerRevealed.value) {
            _isAnswerRevealed.value = true
            if (_selectedOption.value == correctIndex) {
                _currentQuizScore.value += 1
            }
        }
    }

    fun nextQuestion(totalQuestions: Int) {
        if (_quizQuestionIndex.value + 1 < totalQuestions) {
            _quizQuestionIndex.value += 1
            _selectedOption.value = null
            _isAnswerRevealed.value = false
        } else {
            _isQuizCompleted.value = true
            val subject = _activeQuizSubject.value ?: "General"
            repository.recordQuizResult(
                quizTitle = "$subject Mastery Quiz",
                subjectName = subject,
                score = _currentQuizScore.value,
                total = totalQuestions
            )
        }
    }

    fun resetQuiz() {
        _quizQuestionIndex.value = 0
        _selectedOption.value = null
        _isAnswerRevealed.value = false
        _currentQuizScore.value = 0
        _isQuizCompleted.value = false
    }

    fun addCustomQuizQuestion(
        subjectName: String,
        question: String,
        optA: String,
        optB: String,
        optC: String,
        optD: String,
        correctIdx: Int,
        explanation: String
    ) {
        val q = QuizQuestion(
            id = UUID.randomUUID().toString(),
            subjectName = subjectName,
            question = question,
            options = listOf(optA, optB, optC, optD),
            correctIndex = correctIdx,
            explanation = explanation.ifBlank { "Correct option is #${correctIdx + 1}." }
        )
        repository.addQuizQuestion(subjectName, q)
        showBanner("Added new question to $subjectName practice!")
    }

    // --- FOCUS TIMER STATE ---
    private val _focusSecondsRemaining = MutableStateFlow(25 * 60)
    val focusSecondsRemaining: StateFlow<Int> = _focusSecondsRemaining.asStateFlow()

    private val _focusTotalDurationSeconds = MutableStateFlow(25 * 60)
    val focusTotalDurationSeconds: StateFlow<Int> = _focusTotalDurationSeconds.asStateFlow()

    private val _isTimerRunning = MutableStateFlow(false)
    val isTimerRunning: StateFlow<Boolean> = _isTimerRunning.asStateFlow()

    private val _isBreakMode = MutableStateFlow(false)
    val isBreakMode: StateFlow<Boolean> = _isBreakMode.asStateFlow()

    private val _activeFocusSubject = MutableStateFlow("Mathematics")
    val activeFocusSubject: StateFlow<String> = _activeFocusSubject.asStateFlow()

    private val _selectedAmbientSound = MutableStateFlow("Lo-Fi Beats")
    val selectedAmbientSound: StateFlow<String> = _selectedAmbientSound.asStateFlow()

    private val _showFocusCelebration = MutableStateFlow(false)
    val showFocusCelebration: StateFlow<Boolean> = _showFocusCelebration.asStateFlow()

    private var timerJob: Job? = null

    fun setTimerPreset(minutes: Int, isBreak: Boolean = false) {
        pauseTimer()
        _isBreakMode.value = isBreak
        _focusTotalDurationSeconds.value = minutes * 60
        _focusSecondsRemaining.value = minutes * 60
    }

    fun setActiveFocusSubject(subject: String) {
        _activeFocusSubject.value = subject
    }

    fun setSelectedAmbientSound(sound: String) {
        _selectedAmbientSound.value = sound
    }

    fun toggleTimer() {
        if (_isTimerRunning.value) {
            pauseTimer()
        } else {
            startTimer()
        }
    }

    private fun startTimer() {
        _isTimerRunning.value = true
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (_focusSecondsRemaining.value > 0) {
                delay(1000)
                _focusSecondsRemaining.value -= 1
            }
            _isTimerRunning.value = false
            onTimerFinished()
        }
    }

    fun pauseTimer() {
        _isTimerRunning.value = false
        timerJob?.cancel()
    }

    fun resetTimer() {
        pauseTimer()
        _focusSecondsRemaining.value = _focusTotalDurationSeconds.value
    }

    private fun onTimerFinished() {
        if (!_isBreakMode.value) {
            val minutes = _focusTotalDurationSeconds.value / 60
            repository.logFocusSession(
                subjectName = _activeFocusSubject.value,
                durationMinutes = minutes,
                ambientSound = _selectedAmbientSound.value
            )
            _showFocusCelebration.value = true
            showBanner("🎉 Focus Session Completed! +$minutes min logged.")
        } else {
            showBanner("☕ Break finished! Ready for next session?")
        }
    }

    fun dismissCelebration() {
        _showFocusCelebration.value = false
    }

    // --- REMINDERS & DIALOGS ---
    fun setStudyReminder(enabled: Boolean, time: String) {
        repository.setStudyReminder(enabled, time)
        showBanner(if (enabled) "Study reminders set for $time" else "Study reminders turned off")
    }
}
