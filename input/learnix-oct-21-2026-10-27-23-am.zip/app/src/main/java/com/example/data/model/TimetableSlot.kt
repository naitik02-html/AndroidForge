package com.example.data.model

enum class SlotType(val label: String) {
    LECTURE("Lecture"),
    LAB("Laboratory"),
    TUTORIAL("Tutorial"),
    SELF_STUDY("Self Study"),
    EXAM("Exam/Quiz")
}

data class TimetableSlot(
    val id: String,
    val dayOfWeek: Int, // 1 = Monday ... 7 = Sunday
    val startTime: String, // e.g. "09:00 AM"
    val endTime: String,   // e.g. "10:30 AM"
    val subjectName: String,
    val room: String,
    val instructor: String = "",
    val slotType: SlotType = SlotType.LECTURE
)
