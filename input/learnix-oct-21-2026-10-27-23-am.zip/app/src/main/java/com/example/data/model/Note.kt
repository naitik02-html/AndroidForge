package com.example.data.model

data class Note(
    val id: String,
    val title: String,
    val subjectName: String,
    val content: String,
    val isPinned: Boolean = false,
    val updatedAt: String // e.g. "Just now", "Yesterday", "Oct 18"
)
