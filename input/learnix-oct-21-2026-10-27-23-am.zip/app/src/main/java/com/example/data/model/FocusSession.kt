package com.example.data.model

data class FocusSession(
    val id: String,
    val subjectName: String,
    val durationMinutes: Int,
    val completedAt: String,
    val ambientSound: String
)

data class StudentStats(
    val streakDays: Int = 6,
    val totalFocusHours: Float = 18.5f,
    val completedAssignmentsCount: Int = 14,
    val pendingAssignmentsCount: Int = 3,
    val quizzesTakenCount: Int = 8,
    val quizAverageAccuracy: Int = 88, // 88%
    val weeklyStudyHours: List<Pair<String, Float>> = listOf(
        "Mon" to 3.5f,
        "Tue" to 2.8f,
        "Wed" to 4.2f,
        "Thu" to 3.0f,
        "Fri" to 2.5f,
        "Sat" to 4.0f,
        "Sun" to 2.5f
    )
)
