package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

class LearnixRepository {

    // --- TIMETABLE ---
    private val _timetableSlots = MutableStateFlow<List<TimetableSlot>>(getInitialTimetable())
    val timetableSlots: StateFlow<List<TimetableSlot>> = _timetableSlots.asStateFlow()

    fun addTimetableSlot(slot: TimetableSlot) {
        _timetableSlots.update { current ->
            (current + slot).sortedBy { it.startTime }
        }
    }

    fun deleteTimetableSlot(id: String) {
        _timetableSlots.update { current -> current.filterNot { it.id == id } }
    }

    // --- ASSIGNMENTS ---
    private val _assignments = MutableStateFlow<List<Assignment>>(getInitialAssignments())
    val assignments: StateFlow<List<Assignment>> = _assignments.asStateFlow()

    fun toggleAssignmentCompleted(id: String) {
        _assignments.update { list ->
            list.map {
                if (it.id == id) it.copy(isCompleted = !it.isCompleted) else it
            }
        }
        updateAssignmentStats()
    }

    fun addAssignment(assignment: Assignment) {
        _assignments.update { listOf(assignment) + it }
        updateAssignmentStats()
    }

    fun deleteAssignment(id: String) {
        _assignments.update { list -> list.filterNot { it.id == id } }
        updateAssignmentStats()
    }

    // --- NOTES ---
    private val _notes = MutableStateFlow<List<Note>>(getInitialNotes())
    val notes: StateFlow<List<Note>> = _notes.asStateFlow()

    fun addNote(title: String, subjectName: String, content: String) {
        val newNote = Note(
            id = UUID.randomUUID().toString(),
            title = title,
            subjectName = subjectName,
            content = content,
            isPinned = false,
            updatedAt = "Just now"
        )
        _notes.update { listOf(newNote) + it }
    }

    fun updateNote(id: String, title: String, subjectName: String, content: String) {
        _notes.update { list ->
            list.map {
                if (it.id == id) it.copy(
                    title = title,
                    subjectName = subjectName,
                    content = content,
                    updatedAt = "Edited just now"
                ) else it
            }
        }
    }

    fun togglePinNote(id: String) {
        _notes.update { list ->
            list.map {
                if (it.id == id) it.copy(isPinned = !it.isPinned) else it
            }
        }
    }

    fun deleteNote(id: String) {
        _notes.update { list -> list.filterNot { it.id == id } }
    }

    // --- QUIZZES ---
    private val _quizQuestions = MutableStateFlow<Map<String, List<QuizQuestion>>>(getInitialQuizzes())
    val quizQuestions: StateFlow<Map<String, List<QuizQuestion>>> = _quizQuestions.asStateFlow()

    private val _quizHistory = MutableStateFlow<List<QuizScoreRecord>>(getInitialQuizHistory())
    val quizHistory: StateFlow<List<QuizScoreRecord>> = _quizHistory.asStateFlow()

    fun addQuizQuestion(subjectName: String, question: QuizQuestion) {
        _quizQuestions.update { map ->
            val existing = map[subjectName] ?: emptyList()
            map + (subjectName to (existing + question))
        }
    }

    fun recordQuizResult(quizTitle: String, subjectName: String, score: Int, total: Int) {
        val record = QuizScoreRecord(
            id = UUID.randomUUID().toString(),
            quizTitle = quizTitle,
            subjectName = subjectName,
            score = score,
            total = total,
            timestamp = "Today"
        )
        _quizHistory.update { listOf(record) + it }
        // Update stats
        _studentStats.update { stats ->
            val totalQuizzes = stats.quizzesTakenCount + 1
            val newAvg = ((stats.quizAverageAccuracy * stats.quizzesTakenCount) + ((score.toFloat() / total * 100).toInt())) / totalQuizzes
            stats.copy(
                quizzesTakenCount = totalQuizzes,
                quizAverageAccuracy = newAvg
            )
        }
    }

    // --- FOCUS SESSIONS ---
    private val _focusSessions = MutableStateFlow<List<FocusSession>>(getInitialFocusSessions())
    val focusSessions: StateFlow<List<FocusSession>> = _focusSessions.asStateFlow()

    fun logFocusSession(subjectName: String, durationMinutes: Int, ambientSound: String) {
        val session = FocusSession(
            id = UUID.randomUUID().toString(),
            subjectName = subjectName,
            durationMinutes = durationMinutes,
            completedAt = "Just now",
            ambientSound = ambientSound
        )
        _focusSessions.update { listOf(session) + it }
        _studentStats.update { stats ->
            val addedHours = durationMinutes / 60.0f
            stats.copy(totalFocusHours = ((stats.totalFocusHours + addedHours) * 10).toInt() / 10.0f)
        }
    }

    // --- STATS ---
    private val _studentStats = MutableStateFlow(StudentStats())
    val studentStats: StateFlow<StudentStats> = _studentStats.asStateFlow()

    private fun updateAssignmentStats() {
        val completed = _assignments.value.count { it.isCompleted }
        val pending = _assignments.value.count { !it.isCompleted }
        _studentStats.update {
            it.copy(
                completedAssignmentsCount = completed,
                pendingAssignmentsCount = pending
            )
        }
    }

    // --- REMINDERS & PREFERENCES ---
    private val _studyReminderEnabled = MutableStateFlow(true)
    val studyReminderEnabled: StateFlow<Boolean> = _studyReminderEnabled.asStateFlow()

    private val _studyReminderTime = MutableStateFlow("07:30 PM")
    val studyReminderTime: StateFlow<String> = _studyReminderTime.asStateFlow()

    fun setStudyReminder(enabled: Boolean, time: String) {
        _studyReminderEnabled.value = enabled
        _studyReminderTime.value = time
    }

    // --- SEED DATA HELPERS ---
    private fun getInitialTimetable(): List<TimetableSlot> {
        return listOf(
            TimetableSlot("t1", 1, "08:30 AM", "10:00 AM", "Mathematics", "Hall B-204", "Prof. Hastings", SlotType.LECTURE),
            TimetableSlot("t2", 1, "10:30 AM", "12:00 PM", "Physics", "Lab 3", "Dr. Vance", SlotType.LAB),
            TimetableSlot("t3", 1, "01:30 PM", "03:00 PM", "Computer Science", "Room 401", "Prof. Ada", SlotType.LECTURE),
            TimetableSlot("t4", 2, "09:00 AM", "10:30 AM", "Chemistry", "Science Wing 12", "Dr. Marie", SlotType.LECTURE),
            TimetableSlot("t5", 2, "11:00 AM", "12:30 PM", "World History", "Hall A-102", "Prof. Howard", SlotType.LECTURE),
            TimetableSlot("t6", 2, "02:00 PM", "04:00 PM", "Computer Science", "Computer Lab 1", "Prof. Ada", SlotType.LAB),
            TimetableSlot("t7", 3, "09:30 AM", "11:00 AM", "Mathematics", "Hall B-204", "Prof. Hastings", SlotType.TUTORIAL),
            TimetableSlot("t8", 3, "11:30 AM", "01:00 PM", "Literature", "Library Annex", "Prof. Austen", SlotType.LECTURE),
            TimetableSlot("t9", 4, "10:00 AM", "11:30 AM", "Physics", "Auditorium C", "Dr. Vance", SlotType.LECTURE),
            TimetableSlot("t10", 4, "01:00 PM", "02:30 PM", "Biology", "Bio Lab 2", "Dr. Watson", SlotType.LAB),
            TimetableSlot("t11", 5, "09:00 AM", "10:30 AM", "Computer Science", "Room 401", "Prof. Ada", SlotType.LECTURE),
            TimetableSlot("t12", 5, "11:00 AM", "12:30 PM", "Self Study", "Main Study Hall", "Solo Focus", SlotType.SELF_STUDY)
        )
    }

    private fun getInitialAssignments(): List<Assignment> {
        return listOf(
            Assignment(
                id = "a1",
                title = "Calculus Problem Set #4: Multivariable Integrals",
                subjectName = "Mathematics",
                dueDate = "Tomorrow, 11:59 PM",
                daysRemaining = 1,
                priority = Priority.HIGH,
                isCompleted = false,
                notes = "Exercises 4.1 to 4.8 on page 142. Remember to plot 3D cross-sections."
            ),
            Assignment(
                id = "a2",
                title = "Electromagnetism Lab Report & Error Analysis",
                subjectName = "Physics",
                dueDate = "In 2 days",
                daysRemaining = 2,
                priority = Priority.HIGH,
                isCompleted = false,
                notes = "Include data tables from oscilloscope measurements and graph linear fits."
            ),
            Assignment(
                id = "a3",
                title = "Build Binary Search Tree & Balance Algorithm",
                subjectName = "Computer Science",
                dueDate = "Friday, 5:00 PM",
                daysRemaining = 4,
                priority = Priority.MEDIUM,
                isCompleted = false,
                notes = "Implement AVL self-balancing rotations and benchmark search speeds."
            ),
            Assignment(
                id = "a4",
                title = "Essay: Causes of the Industrial Revolution",
                subjectName = "World History",
                dueDate = "Next Monday",
                daysRemaining = 7,
                priority = Priority.LOW,
                isCompleted = false,
                notes = "Minimum 1500 words with primary source citations."
            ),
            Assignment(
                id = "a5",
                title = "Cell Respiration Summary Diagram & Quiz Prep",
                subjectName = "Biology",
                dueDate = "Completed",
                daysRemaining = 0,
                priority = Priority.MEDIUM,
                isCompleted = true,
                notes = "Krebs cycle and ATP synthase stages drawn and annotated."
            )
        )
    }

    private fun getInitialNotes(): List<Note> {
        return listOf(
            Note(
                id = "n1",
                title = "Linear Algebra: Eigenvalues & Matrix Diagonalization",
                subjectName = "Mathematics",
                content = "• Characteristic Equation: det(A - λI) = 0\n• Find roots for eigenvalues λ1, λ2... λn\n• For each λ, solve (A - λI)v = 0 to get eigenvectors.\n• Diagonal matrix D = P⁻¹AP where P has eigenvectors as columns.\n• Application: Google PageRank algorithm & Principal Component Analysis (PCA)!",
                isPinned = true,
                updatedAt = "2 hours ago"
            ),
            Note(
                id = "n2",
                title = "Data Structures: Heap Sort & Priority Queues",
                subjectName = "Computer Science",
                content = "• Max-Heap property: parent node >= children.\n• Array representation: parent at index i -> left child at 2i + 1, right child at 2i + 2.\n• Heapify complexity: O(log N).\n• Building heap in-place: O(N) bottom-up approach.\n• Key usage in Dijkstra's shortest path and Huffman coding.",
                isPinned = true,
                updatedAt = "Yesterday"
            ),
            Note(
                id = "n3",
                title = "Quantum Physics: Wave-Particle Duality & De Broglie",
                subjectName = "Physics",
                content = "• De Broglie wavelength: λ = h / p = h / (mv)\n• Double slit experiment demonstrates interference patterns even with single photons/electrons.\n• Heisenberg Uncertainty Principle: Δx · Δp >= ℏ / 2.\n• Cannot measure position and momentum simultaneously with arbitrary precision.",
                isPinned = false,
                updatedAt = "Oct 18"
            ),
            Note(
                id = "n4",
                title = "Enzyme Kinetics & Michaelis-Menten Model",
                subjectName = "Biology",
                content = "• V0 = (Vmax * [S]) / (Km + [S])\n• Km is the substrate concentration at which reaction rate is half of Vmax.\n• Lower Km indicates higher enzyme affinity for substrate.\n• Competitive inhibitors increase apparent Km without changing Vmax.",
                isPinned = false,
                updatedAt = "Oct 15"
            )
        )
    }

    private fun getInitialQuizzes(): Map<String, List<QuizQuestion>> {
        return mapOf(
            "Computer Science" to listOf(
                QuizQuestion(
                    id = "cs1",
                    subjectName = "Computer Science",
                    question = "What is the worst-case time complexity of QuickSort?",
                    options = listOf("O(N log N)", "O(N²)", "O(N)", "O(log N)"),
                    correctIndex = 1,
                    explanation = "While QuickSort averages O(N log N), unbalanced partitions (e.g., sorted array with first element pivot) degrade performance to O(N²)."
                ),
                QuizQuestion(
                    id = "cs2",
                    subjectName = "Computer Science",
                    question = "Which data structure follows the Last-In-First-Out (LIFO) principle?",
                    options = listOf("Queue", "Stack", "Binary Search Tree", "Hash Map"),
                    correctIndex = 1,
                    explanation = "A Stack processes items in LIFO order, commonly used for function call stacks and undo operations."
                ),
                QuizQuestion(
                    id = "cs3",
                    subjectName = "Computer Science",
                    question = "In relational databases, which SQL clause is used to filter aggregated group results?",
                    options = listOf("WHERE", "GROUP BY", "HAVING", "LIMIT"),
                    correctIndex = 2,
                    explanation = "HAVING filters rows after the GROUP BY aggregation, whereas WHERE filters individual rows before grouping."
                ),
                QuizQuestion(
                    id = "cs4",
                    subjectName = "Computer Science",
                    question = "What does ACID stand for in database management systems?",
                    options = listOf(
                        "Atomicity, Consistency, Isolation, Durability",
                        "Array, Class, Interface, Delegation",
                        "Async, Call, Invoke, Dispatch",
                        "Access, Cache, Index, Distribution"
                    ),
                    correctIndex = 0,
                    explanation = "ACID properties ensure reliable processing of database transactions even in the presence of failures."
                )
            ),
            "Physics" to listOf(
                QuizQuestion(
                    id = "ph1",
                    subjectName = "Physics",
                    question = "What physical constant is represented by 'c' in Einstein's equation E = mc²?",
                    options = listOf("Speed of sound", "Speed of light in vacuum", "Planck's constant", "Gravitational constant"),
                    correctIndex = 1,
                    explanation = "c represents the speed of light in a vacuum (~3.0 x 10⁸ m/s)."
                ),
                QuizQuestion(
                    id = "ph2",
                    subjectName = "Physics",
                    question = "What law states that the induced electromotive force in a closed circuit is proportional to the rate of change of magnetic flux?",
                    options = listOf("Ohm's Law", "Faraday's Law of Induction", "Coulomb's Law", "Hooke's Law"),
                    correctIndex = 1,
                    explanation = "Faraday's Law governs induction, powering electric generators and transformers."
                ),
                QuizQuestion(
                    id = "ph3",
                    subjectName = "Physics",
                    question = "What is the SI unit of electric capacitance?",
                    options = listOf("Henry", "Tesla", "Farad", "Weber"),
                    correctIndex = 2,
                    explanation = "The Farad (F) is the SI unit of capacitance, defined as one coulomb per volt."
                )
            ),
            "Mathematics" to listOf(
                QuizQuestion(
                    id = "ma1",
                    subjectName = "Mathematics",
                    question = "What is the derivative of f(x) = ln(x) for x > 0?",
                    options = listOf("1/x", "e^x", "x", "1/(2x)"),
                    correctIndex = 0,
                    explanation = "The derivative of the natural logarithm ln(x) is 1/x."
                ),
                QuizQuestion(
                    id = "ma2",
                    subjectName = "Mathematics",
                    question = "What is the dot product of two perpendicular vectors?",
                    options = listOf("1", "-1", "0", "Undefined"),
                    correctIndex = 2,
                    explanation = "Because cos(90°) = 0, the dot product u · v = |u||v|cos(θ) equals 0."
                ),
                QuizQuestion(
                    id = "ma3",
                    subjectName = "Mathematics",
                    question = "Which theorem states that in any right triangle, a² + b² = c²?",
                    options = listOf("Fermat's Last Theorem", "Pythagorean Theorem", "Euler's Identity", "Binomial Theorem"),
                    correctIndex = 1,
                    explanation = "The Pythagorean theorem relates the lengths of the legs to the hypotenuse in Euclidean geometry."
                )
            ),
            "Biology" to listOf(
                QuizQuestion(
                    id = "bi1",
                    subjectName = "Biology",
                    question = "Which organelle is known as the powerhouse of eukaryotic cells?",
                    options = listOf("Ribosome", "Endoplasmic Reticulum", "Mitochondria", "Golgi Apparatus"),
                    correctIndex = 2,
                    explanation = "Mitochondria generate most of the cell's ATP supply through oxidative phosphorylation."
                ),
                QuizQuestion(
                    id = "bi2",
                    subjectName = "Biology",
                    question = "Which nitrogenous base pairs with Adenine in DNA?",
                    options = listOf("Guanine", "Cytosine", "Thymine", "Uracil"),
                    correctIndex = 2,
                    explanation = "Adenine pairs with Thymine in DNA via two hydrogen bonds (Uracil replaces Thymine in RNA)."
                )
            )
        )
    }

    private fun getInitialQuizHistory(): List<QuizScoreRecord> {
        return listOf(
            QuizScoreRecord("qh1", "Computer Science: Data Structures", "Computer Science", 4, 4, "Today"),
            QuizScoreRecord("qh2", "Physics: Mechanics & Optics", "Physics", 3, 3, "Yesterday"),
            QuizScoreRecord("qh3", "Calculus Essentials", "Mathematics", 3, 4, "3 days ago")
        )
    }

    private fun getInitialFocusSessions(): List<FocusSession> {
        return listOf(
            FocusSession("fs1", "Mathematics", 45, "Today, 10:15 AM", "Library Rain"),
            FocusSession("fs2", "Computer Science", 50, "Today, 02:30 PM", "Lo-Fi Beats"),
            FocusSession("fs3", "Physics", 25, "Yesterday, 04:00 PM", "Deep Space")
        )
    }
}
