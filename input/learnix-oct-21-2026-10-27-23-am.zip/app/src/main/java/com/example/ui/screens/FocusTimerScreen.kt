package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Subject
import com.example.ui.theme.*

@Composable
fun FocusTimerScreen(
    secondsRemaining: Int,
    totalDurationSeconds: Int,
    isRunning: Boolean,
    isBreakMode: Boolean,
    activeSubject: String,
    selectedAmbientSound: String,
    showCelebration: Boolean,
    onToggleTimer: () -> Unit,
    onResetTimer: () -> Unit,
    onSetPreset: (Int, Boolean) -> Unit,
    onSelectSubject: (String) -> Unit,
    onSelectAmbientSound: (String) -> Unit,
    onDismissCelebration: () -> Unit,
    modifier: Modifier = Modifier
) {
    val progress = if (totalDurationSeconds > 0) {
        1f - (secondsRemaining.toFloat() / totalDurationSeconds)
    } else 0f

    val minutes = secondsRemaining / 60
    val seconds = secondsRemaining % 60
    val formattedTime = String.format("%02d:%02d", minutes, seconds)

    val ambientSounds = listOf("Lo-Fi Beats", "Library Rain", "Deep Space", "White Noise", "Silent")

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = if (isBreakMode) "Study Break ☕" else "Deep Focus Mode ⚡",
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isBreakMode) "Rest your eyes and recharge" else "Block distractions & stay in the zone",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }

            Surface(
                modifier = Modifier.clip(RoundedCornerShape(12.dp)),
                color = if (isBreakMode) MintGreen.copy(alpha = 0.2f) else NeonPurple.copy(alpha = 0.2f),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isBreakMode) MintGreen else NeonPurple
                )
            ) {
                Text(
                    text = if (isBreakMode) "BREAK" else "FOCUS",
                    color = if (isBreakMode) MintGreen else NeonLavender,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }

        // Mode & Presets Row
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                PresetChip(
                    label = "25m Pomodoro",
                    isSelected = !isBreakMode && totalDurationSeconds == 25 * 60,
                    onClick = { onSetPreset(25, false) }
                )
                Spacer(modifier = Modifier.width(8.dp))
                PresetChip(
                    label = "50m Deep Work",
                    isSelected = !isBreakMode && totalDurationSeconds == 50 * 60,
                    onClick = { onSetPreset(50, false) }
                )
                Spacer(modifier = Modifier.width(8.dp))
                PresetChip(
                    label = "5m Break",
                    isSelected = isBreakMode && totalDurationSeconds == 5 * 60,
                    onClick = { onSetPreset(5, true) }
                )
                Spacer(modifier = Modifier.width(8.dp))
                PresetChip(
                    label = "15m Break",
                    isSelected = isBreakMode && totalDurationSeconds == 15 * 60,
                    onClick = { onSetPreset(15, true) }
                )
            }

            // Subject Selector (when in focus mode)
            if (!isBreakMode) {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(Subject.DefaultSubjects) { sub ->
                        val isSel = activeSubject == sub.name
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onSelectSubject(sub.name) },
                            color = if (isSel) sub.color.copy(alpha = 0.3f) else DarkVioletElevated,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSel) sub.color else Color.Transparent
                            )
                        ) {
                            Text(
                                text = sub.name,
                                color = if (isSel) Color.White else TextSecondary,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }
        }

        // Circular Glowing Progress Timer
        Box(
            modifier = Modifier
                .size(260.dp)
                .testTag("circular_timer_container"),
            contentAlignment = Alignment.Center
        ) {
            val primaryColor = if (isBreakMode) MintGreen else NeonPurple
            val secondaryColor = if (isBreakMode) CyanAccent else DeepAmethyst

            Canvas(modifier = Modifier.fillMaxSize()) {
                val strokeWidth = 14.dp.toPx()

                // Background track
                drawCircle(
                    color = Color(0xFF1E173D),
                    radius = (size.minDimension - strokeWidth) / 2,
                    style = Stroke(width = strokeWidth)
                )

                // Progress arc
                drawArc(
                    brush = Brush.sweepGradient(
                        listOf(primaryColor, secondaryColor, primaryColor)
                    ),
                    startAngle = -90f,
                    sweepAngle = progress * 360f,
                    useCenter = false,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = formattedTime,
                    color = TextPrimary,
                    fontSize = 46.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = if (isBreakMode) "Relaxation Break" else activeSubject,
                    color = VividAmethyst,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )

                // Equalizer wave animation when running
                if (isRunning) {
                    SoundWaveVisualizer(color = primaryColor)
                }
            }
        }

        // Ambient Sound Selector
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
            color = DarkVioletElevated
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Headphones,
                        contentDescription = null,
                        tint = VividAmethyst,
                        modifier = Modifier.size(18.dp)
                    )
                    Text("Ambient Sound:", color = TextSecondary, fontSize = 12.sp)
                }

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(ambientSounds) { sound ->
                        val isSel = selectedAmbientSound == sound
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onSelectAmbientSound(sound) },
                            color = if (isSel) DeepAmethyst else Color.Transparent
                        ) {
                            Text(
                                text = sound,
                                color = if (isSel) Color.White else TextTertiary,
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        // Action Buttons (Play / Pause / Reset)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onResetTimer,
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(DarkVioletElevated)
                    .border(1.dp, CardBorder, CircleShape)
                    .testTag("reset_timer_btn")
            ) {
                Icon(
                    imageVector = Icons.Filled.RestartAlt,
                    contentDescription = "Reset Timer",
                    tint = TextSecondary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(24.dp))

            // Main Play/Pause Button
            Button(
                onClick = onToggleTimer,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isBreakMode) MintGreen else NeonPurple
                ),
                shape = CircleShape,
                modifier = Modifier
                    .size(72.dp)
                    .testTag("toggle_timer_btn")
            ) {
                Icon(
                    imageVector = if (isRunning) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (isRunning) "Pause" else "Start",
                    tint = Color.White,
                    modifier = Modifier.size(34.dp)
                )
            }

            Spacer(modifier = Modifier.width(24.dp))

            IconButton(
                onClick = { onSetPreset(if (isBreakMode) 25 else 5, !isBreakMode) },
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(DarkVioletElevated)
                    .border(1.dp, CardBorder, CircleShape)
                    .testTag("switch_mode_btn")
            ) {
                Icon(
                    imageVector = Icons.Filled.FastForward,
                    contentDescription = "Switch Mode",
                    tint = TextSecondary,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }

    // Celebration Dialog when focus ends
    if (showCelebration) {
        AlertDialog(
            onDismissRequest = onDismissCelebration,
            title = {
                Text("Session Completed! 🎉", color = TextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    "Spectacular focus session! Your study minutes have been recorded to your Learning Progress tracker.",
                    color = TextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = onDismissCelebration,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                ) {
                    Text("Awesome!", color = Color.White)
                }
            },
            containerColor = DarkVioletSurface,
            shape = RoundedCornerShape(18.dp)
        )
    }
}

@Composable
private fun PresetChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .border(
                1.dp,
                if (isSelected) NeonPurple else CardBorder,
                RoundedCornerShape(10.dp)
            ),
        color = if (isSelected) DeepAmethyst else DarkVioletElevated
    ) {
        Text(
            text = label,
            color = if (isSelected) Color.White else TextSecondary,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun SoundWaveVisualizer(color: Color) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave")
    val h1 by infiniteTransition.animateFloat(
        initialValue = 6f,
        targetValue = 20f,
        animationSpec = infiniteRepeatable(tween(400, easing = LinearEasing), RepeatMode.Reverse),
        label = "h1"
    )
    val h2 by infiniteTransition.animateFloat(
        initialValue = 18f,
        targetValue = 8f,
        animationSpec = infiniteRepeatable(tween(350, easing = LinearEasing), RepeatMode.Reverse),
        label = "h2"
    )
    val h3 by infiniteTransition.animateFloat(
        initialValue = 10f,
        targetValue = 24f,
        animationSpec = infiniteRepeatable(tween(450, easing = LinearEasing), RepeatMode.Reverse),
        label = "h3"
    )

    Row(
        modifier = Modifier.padding(top = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.width(3.dp).height(h1.dp).clip(CircleShape).background(color))
        Box(modifier = Modifier.width(3.dp).height(h2.dp).clip(CircleShape).background(color))
        Box(modifier = Modifier.width(3.dp).height(h3.dp).clip(CircleShape).background(color))
        Box(modifier = Modifier.width(3.dp).height(h2.dp).clip(CircleShape).background(color))
        Box(modifier = Modifier.width(3.dp).height(h1.dp).clip(CircleShape).background(color))
    }
}
