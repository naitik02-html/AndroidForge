package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.QuizQuestion
import com.example.data.model.QuizScoreRecord
import com.example.data.model.Subject
import com.example.ui.components.AddQuizQuestionDialog
import com.example.ui.components.SubjectTag
import com.example.ui.theme.*

@Composable
fun QuizScreen(
    quizQuestionsMap: Map<String, List<QuizQuestion>>,
    quizHistory: List<QuizScoreRecord>,
    activeSubject: String?,
    questionIndex: Int,
    selectedOption: Int?,
    isAnswerRevealed: Boolean,
    score: Int,
    isQuizCompleted: Boolean,
    onSelectSubject: (String) -> Unit,
    onSelectOption: (Int) -> Unit,
    onSubmitAnswer: (Int) -> Unit,
    onNextQuestion: (Int) -> Unit,
    onResetQuiz: () -> Unit,
    onAddCustomQuestion: (String, String, String, String, String, String, Int, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddDialog by remember { mutableStateOf(false) }

    val currentSubject = activeSubject ?: "Computer Science"
    val questions = quizQuestionsMap[currentSubject] ?: emptyList()
    val totalQuestions = questions.size

    val subjects = remember(quizQuestionsMap) {
        quizQuestionsMap.keys.toList()
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "MCQ Practice & Quiz",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Active recall & concept mastery",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }

                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkVioletElevated),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("add_custom_mcq_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.AddCircleOutline,
                        contentDescription = null,
                        tint = VividAmethyst,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("+ Custom MCQ", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Subject Category Carousel
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(subjects) { sub ->
                    val isSelected = currentSubject == sub
                    val count = quizQuestionsMap[sub]?.size ?: 0
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelectSubject(sub) }
                            .border(
                                1.dp,
                                if (isSelected) NeonPurple else CardBorder,
                                RoundedCornerShape(12.dp)
                            ),
                        color = if (isSelected) DeepAmethyst else DarkVioletElevated
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = sub,
                                color = if (isSelected) Color.White else TextSecondary,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                            Surface(
                                shape = CircleShape,
                                color = if (isSelected) NeonPurple else SurfaceHighlight
                            ) {
                                Text(
                                    text = "$count",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Active Quiz Play Arena or Completion View
            if (questions.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No questions available for $currentSubject.\nTap '+ Custom MCQ' to add one!",
                        color = TextSecondary,
                        fontSize = 14.sp
                    )
                }
            } else if (isQuizCompleted) {
                // Completed Summary Card
                QuizCompletionCard(
                    subjectName = currentSubject,
                    score = score,
                    total = totalQuestions,
                    onRetake = onResetQuiz,
                    modifier = Modifier.weight(1f)
                )
            } else {
                // Current Question Runner
                val currentQuestion = questions.getOrNull(questionIndex) ?: questions.first()

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    item {
                        // Progress Bar & Question Tracker
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Question ${questionIndex + 1} of $totalQuestions",
                                    color = VividAmethyst,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Score: $score",
                                    color = MintGreen,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            LinearProgressIndicator(
                                progress = { (questionIndex + 1).toFloat() / totalQuestions },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = NeonPurple,
                                trackColor = DarkVioletElevated
                            )
                        }
                    }

                    // Question Card
                    item {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .border(1.dp, CardBorder, RoundedCornerShape(18.dp)),
                            color = DarkVioletElevated
                        ) {
                            Column(
                                modifier = Modifier.padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                SubjectTag(subjectName = currentSubject)
                                Text(
                                    text = currentQuestion.question,
                                    color = TextPrimary,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    lineHeight = 22.sp
                                )
                            }
                        }
                    }

                    // Options List
                    items(currentQuestion.options.indices.toList()) { optionIdx ->
                        val optionText = currentQuestion.options[optionIdx]
                        val isSelected = selectedOption == optionIdx
                        val isCorrect = optionIdx == currentQuestion.correctIndex

                        val (cardBg, borderColor, textCol) = when {
                            isAnswerRevealed && isCorrect -> Triple(
                                MintGreen.copy(alpha = 0.2f),
                                MintGreen,
                                MintGreen
                            )
                            isAnswerRevealed && isSelected && !isCorrect -> Triple(
                                CoralPink.copy(alpha = 0.2f),
                                CoralPink,
                                CoralPink
                            )
                            isSelected -> Triple(
                                DeepAmethyst.copy(alpha = 0.5f),
                                NeonPurple,
                                Color.White
                            )
                            else -> Triple(
                                DarkVioletElevated,
                                SurfaceHighlight,
                                TextSecondary
                            )
                        }

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .border(1.dp, borderColor, RoundedCornerShape(14.dp))
                                .clickable(enabled = !isAnswerRevealed) {
                                    onSelectOption(optionIdx)
                                },
                            color = cardBg
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                val optionLetter = ('A' + optionIdx).toString()
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(borderColor.copy(alpha = 0.25f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = optionLetter,
                                        color = textCol,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }

                                Text(
                                    text = optionText,
                                    color = TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.weight(1f)
                                )

                                if (isAnswerRevealed) {
                                    if (isCorrect) {
                                        Icon(
                                            imageVector = Icons.Filled.CheckCircle,
                                            contentDescription = "Correct",
                                            tint = MintGreen,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    } else if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Filled.Cancel,
                                            contentDescription = "Incorrect",
                                            tint = CoralPink,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Explanation Box
                    if (isAnswerRevealed) {
                        item {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .border(1.dp, SurfaceHighlight, RoundedCornerShape(14.dp)),
                                color = DarkVioletSurface
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Lightbulb,
                                            contentDescription = null,
                                            tint = AmberWarning,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = "Concept Breakdown",
                                            color = AmberWarning,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Text(
                                        text = currentQuestion.explanation,
                                        color = TextSecondary,
                                        fontSize = 13.sp,
                                        lineHeight = 18.sp
                                    )
                                }
                            }
                        }
                    }

                    // Bottom Action Button
                    item {
                        if (!isAnswerRevealed) {
                            Button(
                                onClick = { onSubmitAnswer(currentQuestion.correctIndex) },
                                enabled = selectedOption != null,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NeonPurple,
                                    disabledContainerColor = DarkVioletElevated
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("submit_quiz_answer_btn")
                            ) {
                                Text(
                                    text = "Submit Answer",
                                    color = if (selectedOption != null) Color.White else TextTertiary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        } else {
                            Button(
                                onClick = { onNextQuestion(totalQuestions) },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("next_question_btn")
                            ) {
                                Text(
                                    text = if (questionIndex + 1 < totalQuestions) "Next Question →" else "View Results 🏆",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddQuizQuestionDialog(
            initialSubject = currentSubject,
            onAdd = onAddCustomQuestion,
            onDismiss = { showAddDialog = false }
        )
    }
}

@Composable
private fun QuizCompletionCard(
    subjectName: String,
    score: Int,
    total: Int,
    onRetake: () -> Unit,
    modifier: Modifier = Modifier
) {
    val percentage = if (total > 0) (score * 100) / total else 0
    val (badgeText, badgeColor) = when {
        percentage >= 90 -> "Mastery Achieved 🏆" to MintGreen
        percentage >= 70 -> "Great Progress 🌟" to CyanAccent
        percentage >= 50 -> "Solid Effort 📚" to AmberWarning
        else -> "Needs Revision 💡" to CoralPink
    }

    Box(
        modifier = modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .border(1.dp, CardBorder, RoundedCornerShape(22.dp)),
            color = DarkVioletElevated
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(badgeColor.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "$percentage%",
                        color = badgeColor,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = badgeText,
                        color = badgeColor,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "You scored $score out of $total in $subjectName!",
                        color = TextSecondary,
                        fontSize = 14.sp
                    )
                }

                Button(
                    onClick = onRetake,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("retake_quiz_btn")
                ) {
                    Icon(imageVector = Icons.Filled.Replay, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Practice Again", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
