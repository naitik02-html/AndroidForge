package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

data class Subject(
    val id: String,
    val name: String,
    val code: String,
    val color: Color
) {
    companion object {
        val DefaultSubjects = listOf(
            Subject("math", "Mathematics", "MATH-201", SubjectMath),
            Subject("physics", "Physics", "PHYS-101", SubjectPhysics),
            Subject("chemistry", "Chemistry", "CHEM-110", SubjectChemistry),
            Subject("biology", "Biology", "BIO-105", SubjectBiology),
            Subject("cs", "Computer Science", "CS-302", SubjectComputer),
            Subject("history", "World History", "HIST-120", SubjectHistory),
            Subject("lit", "Literature", "ENG-210", SubjectLiterature)
        )

        fun getColorFor(subjectName: String): Color {
            return DefaultSubjects.find { it.name.equals(subjectName, ignoreCase = true) }?.color ?: NeonPurple
        }
    }
}
