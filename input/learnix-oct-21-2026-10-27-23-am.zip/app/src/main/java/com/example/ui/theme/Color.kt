package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Black & Purple Color Palette for Learnix
val DeepOnyx = Color(0xFF090712)         // Main scaffold background
val DarkVioletSurface = Color(0xFF130E26) // Card surface background
val DarkVioletElevated = Color(0xFF1C1538)// Elevated card / input surface
val SurfaceHighlight = Color(0xFF281E4F)  // Active chip / border highlight

val NeonPurple = Color(0xFF9D5CFF)        // Primary accent
val VividAmethyst = Color(0xFFB57CFF)     // Light primary
val DeepAmethyst = Color(0xFF6B26D9)      // Container background
val NeonLavender = Color(0xFFDCC8FF)      // On primary container

val CyanAccent = Color(0xFF00E5FF)        // Secondary highlight (Streak/Timer)
val CoralPink = Color(0xFFFF4D8D)         // High Priority / Alert
val MintGreen = Color(0xFF00E676)         // Done / Success / Correct Quiz
val AmberWarning = Color(0xFFFFB300)      // Medium Priority / Due Soon
val BlueElectric = Color(0xFF2979FF)      // Info / Lecture type

val TextPrimary = Color(0xFFF6F4FF)       // High-emphasis text
val TextSecondary = Color(0xFFADA7C7)     // Medium-emphasis text
val TextTertiary = Color(0xFF756F91)      // Low-emphasis / hint text
val CardBorder = Color(0x339D5CFF)        // Subtle purple glowing border
val DividerColor = Color(0x1FFFFFFF)

// Subject specific colors
val SubjectMath = Color(0xFF2979FF)
val SubjectPhysics = Color(0xFF9D5CFF)
val SubjectChemistry = Color(0xFF00E5FF)
val SubjectBiology = Color(0xFF00E676)
val SubjectHistory = Color(0xFFFFB300)
val SubjectComputer = Color(0xFFFF4D8D)
val SubjectLiterature = Color(0xFFFF7043)
