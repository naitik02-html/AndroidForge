package com.example.data.model

enum class Priority(val label: String) {
    HIGH("High"),
    MEDIUM("Medium"),
    LOW("Low")
}

data class Assignment(
    val id: String,
    val title: String,
    val subjectName: String,
    val dueDate: String, // e.g. "Tomorrow, 5:00 PM" or "Oct 24"
    val daysRemaining: Int, // 0 = today, 1 = tomorrow, -1 = overdue
    val priority: Priority,
    val isCompleted: Boolean = false,
    val notes: String = ""
)
