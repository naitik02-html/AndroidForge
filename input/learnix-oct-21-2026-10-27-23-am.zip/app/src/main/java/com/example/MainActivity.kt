package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.LearnixScreen
import com.example.ui.LearnixViewModel
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.DeepOnyx
import com.example.ui.theme.LearnixTheme

class MainActivity : ComponentActivity() {

    private val viewModel: LearnixViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LearnixTheme {
                LearnixApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun LearnixApp(
    viewModel: LearnixViewModel,
    modifier: Modifier = Modifier
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val studentStats by viewModel.studentStats.collectAsStateWithLifecycle()
    val timetableSlots by viewModel.timetableSlots.collectAsStateWithLifecycle()
    val assignments by viewModel.assignments.collectAsStateWithLifecycle()
    val notes by viewModel.notes.collectAsStateWithLifecycle()
    val quizQuestionsMap by viewModel.quizQuestions.collectAsStateWithLifecycle()
    val quizHistory by viewModel.quizHistory.collectAsStateWithLifecycle()

    val selectedDayOfWeek by viewModel.selectedDayOfWeek.collectAsStateWithLifecycle()
    val assignmentFilter by viewModel.selectedAssignmentFilter.collectAsStateWithLifecycle()
    val notesQuery by viewModel.notesSearchQuery.collectAsStateWithLifecycle()
    val selectedNoteSubject by viewModel.selectedNoteSubject.collectAsStateWithLifecycle()

    // Quiz states
    val activeQuizSubject by viewModel.activeQuizSubject.collectAsStateWithLifecycle()
    val quizQuestionIndex by viewModel.quizQuestionIndex.collectAsStateWithLifecycle()
    val selectedOption by viewModel.selectedOption.collectAsStateWithLifecycle()
    val isAnswerRevealed by viewModel.isAnswerRevealed.collectAsStateWithLifecycle()
    val currentQuizScore by viewModel.currentQuizScore.collectAsStateWithLifecycle()
    val isQuizCompleted by viewModel.isQuizCompleted.collectAsStateWithLifecycle()

    // Focus Timer states
    val focusSecondsRemaining by viewModel.focusSecondsRemaining.collectAsStateWithLifecycle()
    val focusTotalDuration by viewModel.focusTotalDurationSeconds.collectAsStateWithLifecycle()
    val isTimerRunning by viewModel.isTimerRunning.collectAsStateWithLifecycle()
    val isBreakMode by viewModel.isBreakMode.collectAsStateWithLifecycle()
    val activeFocusSubject by viewModel.activeFocusSubject.collectAsStateWithLifecycle()
    val selectedAmbientSound by viewModel.selectedAmbientSound.collectAsStateWithLifecycle()
    val showCelebration by viewModel.showFocusCelebration.collectAsStateWithLifecycle()

    // Reminder states
    val reminderEnabled by viewModel.studyReminderEnabled.collectAsStateWithLifecycle()
    val reminderTime by viewModel.studyReminderTime.collectAsStateWithLifecycle()
    var showRemindersDialog by remember { mutableStateOf(false) }

    // Banner message
    val bannerMessage by viewModel.bannerMessage.collectAsStateWithLifecycle()

    // Handle system back navigation to return to Home screen
    if (currentScreen != LearnixScreen.HOME) {
        BackHandler {
            viewModel.navigateTo(LearnixScreen.HOME)
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(DeepOnyx),
        containerColor = DeepOnyx,
        topBar = {
            LearnixTopBar(
                streakDays = studentStats.streakDays,
                currentScreen = currentScreen,
                onOpenReminders = { showRemindersDialog = true },
                onOpenAnalytics = { viewModel.navigateTo(LearnixScreen.PROGRESS) }
            )
        },
        bottomBar = {
            LearnixBottomBar(
                currentScreen = currentScreen,
                onScreenSelected = { viewModel.navigateTo(it) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // In-App Notification Banner
                NotificationBanner(
                    message = bannerMessage,
                    onDismiss = { viewModel.dismissBanner() }
                )

                Box(modifier = Modifier.weight(1f)) {
                    when (currentScreen) {
                        LearnixScreen.HOME -> HomeScreen(
                            stats = studentStats,
                            todaySlots = timetableSlots.filter { it.dayOfWeek == 1 }, // Default to today's schedule
                            pendingAssignments = assignments.filter { !it.isCompleted },
                            onNavigate = { viewModel.navigateTo(it) },
                            onToggleAssignment = { viewModel.toggleAssignmentCompleted(it) },
                            onStartQuickFocus = {
                                viewModel.setTimerPreset(25, false)
                                viewModel.navigateTo(LearnixScreen.FOCUS)
                            }
                        )

                        LearnixScreen.TIMETABLE -> TimetableScreen(
                            slots = timetableSlots,
                            selectedDayOfWeek = selectedDayOfWeek,
                            onSelectDay = { viewModel.setSelectedDayOfWeek(it) },
                            onAddSlot = { day, start, end, sub, room, inst, type ->
                                viewModel.addTimetableSlot(day, start, end, sub, room, inst, type)
                            },
                            onDeleteSlot = { viewModel.deleteTimetableSlot(it) }
                        )

                        LearnixScreen.TASKS -> TasksScreen(
                            assignments = assignments,
                            currentFilter = assignmentFilter,
                            onSelectFilter = { viewModel.setAssignmentFilter(it) },
                            onToggleAssignment = { viewModel.toggleAssignmentCompleted(it) },
                            onAddAssignment = { title, sub, due, prio, notesText ->
                                viewModel.addAssignment(title, sub, due, prio, notesText)
                            },
                            onDeleteAssignment = { viewModel.deleteAssignment(it) }
                        )

                        LearnixScreen.NOTES -> NotesScreen(
                            notes = notes,
                            searchQuery = notesQuery,
                            selectedSubject = selectedNoteSubject,
                            onSearchChange = { viewModel.setNotesSearchQuery(it) },
                            onSelectSubject = { viewModel.setSelectedNoteSubject(it) },
                            onAddNote = { title, sub, content ->
                                viewModel.addNote(title, sub, content)
                            },
                            onUpdateNote = { id, title, sub, content ->
                                viewModel.updateNote(id, title, sub, content)
                            },
                            onTogglePinNote = { viewModel.togglePinNote(it) },
                            onDeleteNote = { viewModel.deleteNote(it) }
                        )

                        LearnixScreen.QUIZ -> QuizScreen(
                            quizQuestionsMap = quizQuestionsMap,
                            quizHistory = quizHistory,
                            activeSubject = activeQuizSubject,
                            questionIndex = quizQuestionIndex,
                            selectedOption = selectedOption,
                            isAnswerRevealed = isAnswerRevealed,
                            score = currentQuizScore,
                            isQuizCompleted = isQuizCompleted,
                            onSelectSubject = { viewModel.selectQuizSubject(it) },
                            onSelectOption = { viewModel.selectOption(it) },
                            onSubmitAnswer = { viewModel.submitAnswer(it) },
                            onNextQuestion = { viewModel.nextQuestion(it) },
                            onResetQuiz = { viewModel.resetQuiz() },
                            onAddCustomQuestion = { sub, q, a, b, c, d, correct, exp ->
                                viewModel.addCustomQuizQuestion(sub, q, a, b, c, d, correct, exp)
                            }
                        )

                        LearnixScreen.FOCUS -> FocusTimerScreen(
                            secondsRemaining = focusSecondsRemaining,
                            totalDurationSeconds = focusTotalDuration,
                            isRunning = isTimerRunning,
                            isBreakMode = isBreakMode,
                            activeSubject = activeFocusSubject,
                            selectedAmbientSound = selectedAmbientSound,
                            showCelebration = showCelebration,
                            onToggleTimer = { viewModel.toggleTimer() },
                            onResetTimer = { viewModel.resetTimer() },
                            onSetPreset = { mins, isBreak -> viewModel.setTimerPreset(mins, isBreak) },
                            onSelectSubject = { viewModel.setActiveFocusSubject(it) },
                            onSelectAmbientSound = { viewModel.setSelectedAmbientSound(it) },
                            onDismissCelebration = { viewModel.dismissCelebration() }
                        )

                        LearnixScreen.PROGRESS -> ProgressScreen(
                            stats = studentStats,
                            quizHistory = quizHistory
                        )
                    }
                }
            }
        }
    }

    if (showRemindersDialog) {
        RemindersDialog(
            initialEnabled = reminderEnabled,
            initialTime = reminderTime,
            onSave = { enabled, time ->
                viewModel.setStudyReminder(enabled, time)
            },
            onDismiss = { showRemindersDialog = false }
        )
    }
}
