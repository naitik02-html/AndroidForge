package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.QuizScoreRecord
import com.example.data.model.StudentStats
import com.example.ui.components.SubjectTag
import com.example.ui.theme.*

@Composable
fun ProgressScreen(
    stats: StudentStats,
    quizHistory: List<QuizScoreRecord>,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "Learning Progress",
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Your consistency, study hours & milestones",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        // Streak Card
        item {
            StreakBannerCard(streakDays = stats.streakDays)
        }

        // Weekly Study Hours Bar Chart
        item {
            WeeklyHoursChartCard(weeklyHours = stats.weeklyStudyHours)
        }

        // Homework & Quiz Stats Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Homework Card
                SummaryMetricCard(
                    title = "Homework",
                    value = "${stats.completedAssignmentsCount} Done",
                    subtitle = "${stats.pendingAssignmentsCount} Pending",
                    icon = Icons.Filled.AssignmentTurnedIn,
                    color = MintGreen,
                    modifier = Modifier.weight(1f)
                )

                // Quiz Accuracy Card
                SummaryMetricCard(
                    title = "Quiz Accuracy",
                    value = "${stats.quizAverageAccuracy}%",
                    subtitle = "${stats.quizzesTakenCount} Quizzes",
                    icon = Icons.Filled.Psychology,
                    color = CyanAccent,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Badges Section
        item {
            StudentBadgesSection()
        }

        // Recent Quiz Attempts History
        item {
            RecentQuizHistorySection(history = quizHistory)
        }
    }
}

@Composable
private fun StreakBannerCard(streakDays: Int) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, CardBorder, RoundedCornerShape(18.dp))
            .testTag("streak_banner_card"),
        color = DarkVioletElevated
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(AmberWarning.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.LocalFireDepartment,
                            contentDescription = null,
                            tint = AmberWarning,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "$streakDays Day Streak 🔥",
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "You're on fire! Keep studying every day.",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // Weekday check-in bubbles
            val weekDays = listOf("M", "T", "W", "T", "F", "S", "S")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                weekDays.forEachIndexed { idx, day ->
                    val isChecked = idx < streakDays
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(if (isChecked) AmberWarning else SurfaceHighlight),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isChecked) {
                                Icon(
                                    imageVector = Icons.Filled.Check,
                                    contentDescription = null,
                                    tint = DeepOnyx,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        Text(
                            text = day,
                            color = if (isChecked) AmberWarning else TextTertiary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun WeeklyHoursChartCard(weeklyHours: List<Pair<String, Float>>) {
    val maxHours = (weeklyHours.maxOfOrNull { it.second } ?: 4.5f).coerceAtLeast(1f)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, CardBorder, RoundedCornerShape(18.dp)),
        color = DarkVioletElevated
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Weekly Focus Hours",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Total: ${weeklyHours.sumOf { it.second.toDouble() }.toFloat()} hrs logged",
                        color = VividAmethyst,
                        fontSize = 12.sp
                    )
                }

                Icon(
                    imageVector = Icons.Filled.BarChart,
                    contentDescription = null,
                    tint = NeonPurple
                )
            }

            // Custom Canvas Bar Chart
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
            ) {
                val barWidth = 24.dp.toPx()
                val totalBars = weeklyHours.size
                val spacing = (size.width - (barWidth * totalBars)) / (totalBars + 1)
                val chartHeight = size.height - 24.dp.toPx()

                weeklyHours.forEachIndexed { i, (_, hours) ->
                    val x = spacing + i * (barWidth + spacing)
                    val barHeight = (hours / maxHours) * chartHeight
                    val y = chartHeight - barHeight

                    // Bar Background Track
                    drawRoundRect(
                        color = Color(0xFF1E173D),
                        topLeft = Offset(x, 0f),
                        size = Size(barWidth, chartHeight),
                        cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                    )

                    // Active Bar
                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            listOf(NeonPurple, VividAmethyst)
                        ),
                        topLeft = Offset(x, y),
                        size = Size(barWidth, barHeight),
                        cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                    )
                }
            }

            // Labels below bars
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                weeklyHours.forEach { (day, hours) ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = day,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${hours}h",
                            color = TextTertiary,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryMetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
        color = DarkVioletElevated
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(20.dp)
                )
            }

            Column {
                Text(text = title, color = TextSecondary, fontSize = 12.sp)
                Text(
                    text = value,
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(text = subtitle, color = color, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun StudentBadgesSection() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "Achievements & Badges",
            color = TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            BadgeItem(title = "Night Owl", icon = "🦉", isUnlocked = true, modifier = Modifier.weight(1f))
            BadgeItem(title = "Pomodoro Pro", icon = "⏱️", isUnlocked = true, modifier = Modifier.weight(1f))
            BadgeItem(title = "Quiz Master", icon = "🧠", isUnlocked = true, modifier = Modifier.weight(1f))
            BadgeItem(title = "7-Day Streak", icon = "🔥", isUnlocked = false, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun BadgeItem(
    title: String,
    icon: String,
    isUnlocked: Boolean,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, if (isUnlocked) CardBorder else SurfaceHighlight, RoundedCornerShape(14.dp)),
        color = DarkVioletElevated
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = icon,
                fontSize = 24.sp
            )
            Text(
                text = title,
                color = if (isUnlocked) TextPrimary else TextTertiary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = if (isUnlocked) "Unlocked" else "Locked",
                color = if (isUnlocked) MintGreen else TextTertiary,
                fontSize = 9.sp
            )
        }
    }
}

@Composable
private fun RecentQuizHistorySection(history: List<QuizScoreRecord>) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "Recent Quiz Activity",
            color = TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )

        if (history.isEmpty()) {
            Text("No quiz activity yet.", color = TextSecondary, fontSize = 13.sp)
        } else {
            history.forEach { record ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.dp, CardBorder, RoundedCornerShape(14.dp)),
                    color = DarkVioletElevated
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            SubjectTag(subjectName = record.subjectName)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = record.quizTitle,
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = record.timestamp,
                                color = TextTertiary,
                                fontSize = 11.sp
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (record.score == record.total) MintGreen.copy(alpha = 0.2f) else DeepAmethyst
                        ) {
                            Text(
                                text = "${record.score}/${record.total}",
                                color = if (record.score == record.total) MintGreen else Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
