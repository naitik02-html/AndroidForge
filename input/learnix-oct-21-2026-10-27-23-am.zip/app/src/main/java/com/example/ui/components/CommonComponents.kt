package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Priority
import com.example.data.model.Subject
import com.example.ui.LearnixScreen
import com.example.ui.theme.*

@Composable
fun LearnixTopBar(
    streakDays: Int,
    currentScreen: LearnixScreen,
    onOpenReminders: () -> Unit,
    onOpenAnalytics: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(NeonPurple, DeepAmethyst)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.MenuBook,
                    contentDescription = "Learnix Logo",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }
            Column {
                Text(
                    text = "Learnix",
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = currentScreen.title,
                    color = VividAmethyst,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Streak Pill
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { onOpenAnalytics() }
                    .testTag("streak_pill"),
                color = DarkVioletElevated,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.LocalFireDepartment,
                        contentDescription = "Streak",
                        tint = AmberWarning,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "$streakDays d",
                        color = AmberWarning,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Reminders Button
            IconButton(
                onClick = onOpenReminders,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(DarkVioletElevated)
                    .testTag("reminders_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Notifications,
                    contentDescription = "Study Reminders",
                    tint = VividAmethyst,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun LearnixBottomBar(
    currentScreen: LearnixScreen,
    onScreenSelected: (LearnixScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars),
        color = DeepOnyx,
        tonalElevation = 8.dp,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            Brush.verticalGradient(listOf(SurfaceHighlight, Color.Transparent))
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomNavItem(
                title = "Home",
                icon = Icons.Filled.Dashboard,
                isSelected = currentScreen == LearnixScreen.HOME,
                onClick = { onScreenSelected(LearnixScreen.HOME) },
                testTag = "nav_home"
            )
            BottomNavItem(
                title = "Planner",
                icon = Icons.Filled.CalendarMonth,
                isSelected = currentScreen == LearnixScreen.TIMETABLE,
                onClick = { onScreenSelected(LearnixScreen.TIMETABLE) },
                testTag = "nav_timetable"
            )
            BottomNavItem(
                title = "Tasks",
                icon = Icons.Filled.CheckCircle,
                isSelected = currentScreen == LearnixScreen.TASKS,
                onClick = { onScreenSelected(LearnixScreen.TASKS) },
                testTag = "nav_tasks"
            )
            BottomNavItem(
                title = "Notes",
                icon = Icons.Filled.EditNote,
                isSelected = currentScreen == LearnixScreen.NOTES,
                onClick = { onScreenSelected(LearnixScreen.NOTES) },
                testTag = "nav_notes"
            )
            BottomNavItem(
                title = "Quiz",
                icon = Icons.Filled.Psychology,
                isSelected = currentScreen == LearnixScreen.QUIZ,
                onClick = { onScreenSelected(LearnixScreen.QUIZ) },
                testTag = "nav_quiz"
            )
            BottomNavItem(
                title = "Timer",
                icon = Icons.Filled.Timer,
                isSelected = currentScreen == LearnixScreen.FOCUS,
                onClick = { onScreenSelected(LearnixScreen.FOCUS) },
                testTag = "nav_timer"
            )
        }
    }
}

@Composable
private fun BottomNavItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    val animatedBg = if (isSelected) DeepAmethyst.copy(alpha = 0.4f) else Color.Transparent
    val tintColor = if (isSelected) NeonPurple else TextTertiary

    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .background(animatedBg)
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag(testTag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = tintColor,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = title,
            color = tintColor,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
fun SubjectTag(
    subjectName: String,
    modifier: Modifier = Modifier
) {
    val color = Subject.getColorFor(subjectName)
    Surface(
        modifier = modifier.clip(RoundedCornerShape(8.dp)),
        color = color.copy(alpha = 0.15f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f))
    ) {
        Text(
            text = subjectName,
            color = color,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun PriorityBadge(priority: Priority) {
    val (color, text) = when (priority) {
        Priority.HIGH -> CoralPink to "High"
        Priority.MEDIUM -> AmberWarning to "Medium"
        Priority.LOW -> CyanAccent to "Low"
    }

    Surface(
        modifier = Modifier.clip(RoundedCornerShape(6.dp)),
        color = color.copy(alpha = 0.15f)
    ) {
        Text(
            text = text,
            color = color,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun NotificationBanner(
    message: String?,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = message != null,
        enter = fadeIn() + slideInVertically(initialOffsetY = { -it }),
        exit = fadeOut() + slideOutVertically(targetOffsetY = { -it }),
        modifier = modifier
    ) {
        if (message != null) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onDismiss() }
                    .testTag("notification_banner"),
                color = DarkVioletElevated,
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonPurple)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.NotificationsActive,
                        contentDescription = "Alert",
                        tint = NeonPurple,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = message,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Dismiss",
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}
