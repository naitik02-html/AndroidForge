package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Assignment
import com.example.data.model.StudentStats
import com.example.data.model.Subject
import com.example.data.model.TimetableSlot
import com.example.ui.LearnixScreen
import com.example.ui.components.PriorityBadge
import com.example.ui.components.SubjectTag
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    stats: StudentStats,
    todaySlots: List<TimetableSlot>,
    pendingAssignments: List<Assignment>,
    onNavigate: (LearnixScreen) -> Unit,
    onToggleAssignment: (String) -> Unit,
    onStartQuickFocus: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
    ) {
        // Hero Student Banner
        item {
            HeroWelcomeCard(
                streakDays = stats.streakDays,
                onStartQuickFocus = onStartQuickFocus,
                onViewAnalytics = { onNavigate(LearnixScreen.PROGRESS) }
            )
        }

        // Quick Actions Row
        item {
            QuickActionsRow(onNavigate = onNavigate)
        }

        // Next Up Class
        item {
            NextUpClassSection(
                slots = todaySlots,
                onViewFullTimetable = { onNavigate(LearnixScreen.TIMETABLE) }
            )
        }

        // Urgent Assignments Section
        item {
            UrgentAssignmentsSection(
                assignments = pendingAssignments.take(3),
                onToggleAssignment = onToggleAssignment,
                onViewAllTasks = { onNavigate(LearnixScreen.TASKS) }
            )
        }

        // Progress Overview Card
        item {
            WeeklyProgressCard(
                stats = stats,
                onViewAnalytics = { onNavigate(LearnixScreen.PROGRESS) }
            )
        }
    }
}

@Composable
private fun HeroWelcomeCard(
    streakDays: Int,
    onStartQuickFocus: () -> Unit,
    onViewAnalytics: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .border(
                1.dp,
                Brush.horizontalGradient(listOf(NeonPurple, DeepAmethyst)),
                RoundedCornerShape(20.dp)
            )
            .testTag("hero_welcome_card"),
        color = DarkVioletSurface
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.radialGradient(
                        colors = listOf(DeepAmethyst.copy(alpha = 0.35f), Color.Transparent),
                        radius = 450f
                    )
                )
                .padding(20.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Welcome back, Scholar 🚀",
                            color = TextPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "“Small steps every day lead to big results.”",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    // Streak Badge
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable(onClick = onViewAnalytics),
                        color = AmberWarning.copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AmberWarning.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.LocalFireDepartment,
                                contentDescription = null,
                                tint = AmberWarning,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "$streakDays Days",
                                color = AmberWarning,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onStartQuickFocus,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("quick_focus_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Timer,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Start 25m Focus",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    OutlinedButton(
                        onClick = onViewAnalytics,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = VividAmethyst),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("view_stats_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.BarChart,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Stats", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickActionsRow(onNavigate: (LearnixScreen) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        QuickActionItem(
            title = "Planner",
            subtitle = "Schedule",
            icon = Icons.Filled.CalendarMonth,
            color = SubjectMath,
            onClick = { onNavigate(LearnixScreen.TIMETABLE) },
            modifier = Modifier.weight(1f)
        )
        QuickActionItem(
            title = "Homework",
            subtitle = "Tasks",
            icon = Icons.Filled.Checklist,
            color = MintGreen,
            onClick = { onNavigate(LearnixScreen.TASKS) },
            modifier = Modifier.weight(1f)
        )
        QuickActionItem(
            title = "Notes",
            subtitle = "Notebook",
            icon = Icons.Filled.EditNote,
            color = VividAmethyst,
            onClick = { onNavigate(LearnixScreen.NOTES) },
            modifier = Modifier.weight(1f)
        )
        QuickActionItem(
            title = "Practice",
            subtitle = "Quizzes",
            icon = Icons.Filled.Psychology,
            color = CyanAccent,
            onClick = { onNavigate(LearnixScreen.QUIZ) },
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun QuickActionItem(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
        color = DarkVioletElevated
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(20.dp)
                )
            }
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtitle,
                color = TextTertiary,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
private fun NextUpClassSection(
    slots: List<TimetableSlot>,
    onViewFullTimetable: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Today's Schedule",
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "See All",
                color = NeonPurple,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable(onClick = onViewFullTimetable)
            )
        }

        if (slots.isEmpty()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp)),
                color = DarkVioletElevated
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.BeachAccess,
                        contentDescription = null,
                        tint = VividAmethyst
                    )
                    Text(
                        text = "No classes scheduled for today. Great day for self study!",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            val nextSlot = slots.first()
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, CardBorder, RoundedCornerShape(16.dp))
                    .clickable(onClick = onViewFullTimetable),
                color = DarkVioletElevated
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(com.example.data.model.Subject.getColorFor(nextSlot.subjectName).copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.School,
                            contentDescription = null,
                            tint = com.example.data.model.Subject.getColorFor(nextSlot.subjectName),
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            SubjectTag(subjectName = nextSlot.subjectName)
                            Text(
                                text = nextSlot.slotType.label,
                                color = TextTertiary,
                                fontSize = 11.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${nextSlot.startTime} - ${nextSlot.endTime}",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${nextSlot.room} • ${nextSlot.instructor.ifBlank { "Campus" }}",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    Icon(
                        imageVector = Icons.Filled.ChevronRight,
                        contentDescription = "Go",
                        tint = TextTertiary
                    )
                }
            }
        }
    }
}

@Composable
private fun UrgentAssignmentsSection(
    assignments: List<Assignment>,
    onToggleAssignment: (String) -> Unit,
    onViewAllTasks: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Urgent Homework",
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "View All",
                color = NeonPurple,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable(onClick = onViewAllTasks)
            )
        }

        if (assignments.isEmpty()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp)),
                color = DarkVioletElevated
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircleOutline,
                        contentDescription = null,
                        tint = MintGreen
                    )
                    Text(
                        text = "All assignments submitted! You're completely up to date.",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            assignments.forEach { task ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.dp, CardBorder, RoundedCornerShape(14.dp)),
                    color = DarkVioletElevated
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        IconButton(
                            onClick = { onToggleAssignment(task.id) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = if (task.isCompleted) Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                                contentDescription = "Toggle",
                                tint = if (task.isCompleted) MintGreen else TextTertiary
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                SubjectTag(subjectName = task.subjectName)
                                PriorityBadge(priority = task.priority)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = task.title,
                                color = if (task.isCompleted) TextTertiary else TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textDecoration = if (task.isCompleted) TextDecoration.LineThrough else null
                            )
                            Text(
                                text = "Due: ${task.dueDate}",
                                color = if (task.daysRemaining <= 1) CoralPink else TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WeeklyProgressCard(
    stats: StudentStats,
    onViewAnalytics: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, CardBorder, RoundedCornerShape(18.dp))
            .clickable(onClick = onViewAnalytics),
        color = DarkVioletElevated
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.TrendingUp,
                        contentDescription = null,
                        tint = NeonPurple
                    )
                    Text(
                        text = "Learning Performance",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Icon(
                    imageVector = Icons.Filled.ArrowForward,
                    contentDescription = null,
                    tint = TextTertiary,
                    modifier = Modifier.size(16.dp)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                StatPill(
                    label = "Focus Hours",
                    value = "${stats.totalFocusHours}h",
                    color = NeonPurple
                )
                StatPill(
                    label = "Tasks Done",
                    value = "${stats.completedAssignmentsCount}",
                    color = MintGreen
                )
                StatPill(
                    label = "Quiz Accuracy",
                    value = "${stats.quizAverageAccuracy}%",
                    color = CyanAccent
                )
            }
        }
    }
}

@Composable
private fun StatPill(
    label: String,
    value: String,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(
            text = value,
            color = color,
            fontSize = 18.sp,
            fontWeight = FontWeight.ExtraBold
        )
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 11.sp
        )
    }
}
