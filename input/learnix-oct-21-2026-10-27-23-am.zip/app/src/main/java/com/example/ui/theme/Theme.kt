package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LearnixDarkColorScheme = darkColorScheme(
    primary = NeonPurple,
    onPrimary = DeepOnyx,
    primaryContainer = DeepAmethyst,
    onPrimaryContainer = NeonLavender,
    secondary = CyanAccent,
    onSecondary = DeepOnyx,
    secondaryContainer = SurfaceHighlight,
    onSecondaryContainer = TextPrimary,
    tertiary = CoralPink,
    onTertiary = DeepOnyx,
    background = DeepOnyx,
    onBackground = TextPrimary,
    surface = DarkVioletSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkVioletElevated,
    onSurfaceVariant = TextSecondary,
    outline = CardBorder
)

@Composable
fun LearnixTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = DeepOnyx.toArgb()
                window.navigationBarColor = DeepOnyx.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = LearnixDarkColorScheme,
        typography = Typography,
        content = content
    )
}

// Keep MyApplicationTheme as alias for compatibility
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    LearnixTheme(content = content)
}
