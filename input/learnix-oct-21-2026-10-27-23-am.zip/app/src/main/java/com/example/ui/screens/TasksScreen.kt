package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Assignment
import com.example.data.model.Priority
import com.example.ui.AssignmentFilter
import com.example.ui.components.AddAssignmentDialog
import com.example.ui.components.PriorityBadge
import com.example.ui.components.SubjectTag
import com.example.ui.theme.*

@Composable
fun TasksScreen(
    assignments: List<Assignment>,
    currentFilter: AssignmentFilter,
    onSelectFilter: (AssignmentFilter) -> Unit,
    onToggleAssignment: (String) -> Unit,
    onAddAssignment: (String, String, String, Priority, String) -> Unit,
    onDeleteAssignment: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddDialog by remember { mutableStateOf(false) }

    val filteredList = remember(assignments, currentFilter) {
        when (currentFilter) {
            AssignmentFilter.ALL -> assignments
            AssignmentFilter.PENDING -> assignments.filter { !it.isCompleted }
            AssignmentFilter.COMPLETED -> assignments.filter { it.isCompleted }
            AssignmentFilter.HIGH_PRIORITY -> assignments.filter { it.priority == Priority.HIGH }
        }
    }

    val pendingCount = assignments.count { !it.isCompleted }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Homework Tracker",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "$pendingCount pending assignment${if (pendingCount != 1) "s" else ""}",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DarkVioletElevated,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                ) {
                    Text(
                        text = "${assignments.count { it.isCompleted }}/${assignments.size} Done",
                        color = MintGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            // Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(AssignmentFilter.values()) { filter ->
                    val isSelected = currentFilter == filter
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelectFilter(filter) }
                            .border(
                                1.dp,
                                if (isSelected) NeonPurple else CardBorder,
                                RoundedCornerShape(12.dp)
                            ),
                        color = if (isSelected) DeepAmethyst else DarkVioletElevated
                    ) {
                        Text(
                            text = filter.label,
                            color = if (isSelected) Color.White else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
            }

            // Assignment Cards List
            if (filteredList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(DarkVioletElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ChecklistRtl,
                                contentDescription = null,
                                tint = NeonPurple,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Text(
                            text = "No assignments in this filter",
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Tap + to add your next assignment or homework task.",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredList) { task ->
                        AssignmentCard(
                            assignment = task,
                            onToggle = { onToggleAssignment(task.id) },
                            onDelete = { onDeleteAssignment(task.id) }
                        )
                    }
                }
            }
        }

        // FAB to add assignment
        FloatingActionButton(
            onClick = { showAddDialog = true },
            containerColor = NeonPurple,
            contentColor = Color.White,
            shape = CircleShape,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 16.dp, end = 16.dp)
                .testTag("add_assignment_fab")
        ) {
            Icon(imageVector = Icons.Filled.Add, contentDescription = "Add Homework")
        }
    }

    if (showAddDialog) {
        AddAssignmentDialog(
            onAdd = onAddAssignment,
            onDismiss = { showAddDialog = false }
        )
    }
}

@Composable
private fun AssignmentCard(
    assignment: Assignment,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(
                1.dp,
                if (assignment.isCompleted) CardBorder else SurfaceHighlight,
                RoundedCornerShape(16.dp)
            )
            .clickable { isExpanded = !isExpanded },
        color = DarkVioletElevated
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                IconButton(
                    onClick = onToggle,
                    modifier = Modifier.size(28.dp).testTag("toggle_task_${assignment.id}")
                ) {
                    Icon(
                        imageVector = if (assignment.isCompleted) Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                        contentDescription = "Toggle Complete",
                        tint = if (assignment.isCompleted) MintGreen else TextTertiary
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SubjectTag(subjectName = assignment.subjectName)
                        PriorityBadge(priority = assignment.priority)
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = assignment.title,
                        color = if (assignment.isCompleted) TextTertiary else TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        textDecoration = if (assignment.isCompleted) TextDecoration.LineThrough else null
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.DeleteOutline,
                        contentDescription = "Delete",
                        tint = TextTertiary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 38.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.AccessTime,
                        contentDescription = null,
                        tint = if (assignment.daysRemaining <= 1 && !assignment.isCompleted) CoralPink else TextSecondary,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = assignment.dueDate,
                        color = if (assignment.daysRemaining <= 1 && !assignment.isCompleted) CoralPink else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                if (assignment.notes.isNotBlank()) {
                    Text(
                        text = if (isExpanded) "Hide details ▲" else "Details ▼",
                        color = VividAmethyst,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            AnimatedVisibility(visible = isExpanded && assignment.notes.isNotBlank()) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 38.dp, top = 4.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    color = DarkVioletSurface
                ) {
                    Text(
                        text = assignment.notes,
                        color = TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }
    }
}
