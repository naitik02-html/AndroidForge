package com.example.data.model

data class QuizQuestion(
    val id: String,
    val subjectName: String,
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String
)

data class QuizCategory(
    val id: String,
    val title: String,
    val subjectName: String,
    val description: String,
    val totalQuestions: Int,
    val iconName: String = "quiz"
)

data class QuizScoreRecord(
    val id: String,
    val quizTitle: String,
    val subjectName: String,
    val score: Int,
    val total: Int,
    val timestamp: String
)
