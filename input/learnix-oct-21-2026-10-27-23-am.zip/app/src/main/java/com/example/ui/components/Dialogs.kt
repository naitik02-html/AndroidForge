package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Priority
import com.example.data.model.SlotType
import com.example.data.model.Subject
import com.example.ui.theme.*

@Composable
fun RemindersDialog(
    initialEnabled: Boolean,
    initialTime: String,
    onSave: (Boolean, String) -> Unit,
    onDismiss: () -> Unit
) {
    var isEnabled by remember { mutableStateOf(initialEnabled) }
    var selectedTime by remember { mutableStateOf(initialTime) }

    val presetTimes = listOf("06:00 PM", "07:30 PM", "08:30 PM", "09:00 PM", "10:00 PM")

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .testTag("reminders_dialog"),
            color = DarkVioletSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.NotificationsActive,
                            contentDescription = "Notifications",
                            tint = NeonPurple
                        )
                        Text(
                            text = "Study Reminders",
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Switch(
                        checked = isEnabled,
                        onCheckedChange = { isEnabled = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = NeonPurple,
                            uncheckedThumbColor = TextTertiary,
                            uncheckedTrackColor = DarkVioletElevated
                        ),
                        modifier = Modifier.testTag("reminder_switch")
                    )
                }

                Text(
                    text = "Stay disciplined with daily study reminders & homework deadline alerts.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )

                if (isEnabled) {
                    Text(
                        text = "Preferred Reminder Time",
                        color = VividAmethyst,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        presetTimes.take(3).forEach { time ->
                            TimePresetChip(
                                time = time,
                                isSelected = selectedTime == time,
                                onSelect = { selectedTime = time }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        presetTimes.drop(3).forEach { time ->
                            TimePresetChip(
                                time = time,
                                isSelected = selectedTime == time,
                                onSelect = { selectedTime = time }
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            onSave(isEnabled, selectedTime)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("save_reminders_button")
                    ) {
                        Text("Save Settings", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun TimePresetChip(
    time: String,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onSelect),
        color = if (isSelected) DeepAmethyst else DarkVioletElevated,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) NeonPurple else SurfaceHighlight
        )
    ) {
        Text(
            text = time,
            color = if (isSelected) Color.White else TextSecondary,
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTimetableSlotDialog(
    initialDayOfWeek: Int,
    onAdd: (Int, String, String, String, String, String, SlotType) -> Unit,
    onDismiss: () -> Unit
) {
    var day by remember { mutableStateOf(initialDayOfWeek) }
    var subjectName by remember { mutableStateOf(Subject.DefaultSubjects.first().name) }
    var startTime by remember { mutableStateOf("09:00 AM") }
    var endTime by remember { mutableStateOf("10:30 AM") }
    var room by remember { mutableStateOf("Room 201") }
    var instructor by remember { mutableStateOf("") }
    var slotType by remember { mutableStateOf(SlotType.LECTURE) }

    val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .testTag("add_slot_dialog"),
            color = DarkVioletSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "Add Class / Study Slot",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                // Day of Week
                Text("Select Day", color = TextSecondary, fontSize = 12.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    days.forEachIndexed { index, name ->
                        val dayNum = index + 1
                        val isSel = day == dayNum
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) NeonPurple else DarkVioletElevated)
                                .clickable { day = dayNum }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = name,
                                color = if (isSel) Color.White else TextSecondary,
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                // Subject Selector
                Text("Subject", color = TextSecondary, fontSize = 12.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Subject.DefaultSubjects.take(4).forEach { sub ->
                        val isSel = subjectName == sub.name
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { subjectName = sub.name },
                            color = if (isSel) sub.color.copy(alpha = 0.3f) else DarkVioletElevated,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSel) sub.color else Color.Transparent
                            )
                        ) {
                            Text(
                                text = sub.name.take(7),
                                color = if (isSel) Color.White else TextSecondary,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = subjectName,
                    onValueChange = { subjectName = it },
                    label = { Text("Subject Name") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonPurple,
                        unfocusedBorderColor = SurfaceHighlight,
                        focusedContainerColor = DarkVioletElevated,
                        unfocusedContainerColor = DarkVioletElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = startTime,
                        onValueChange = { startTime = it },
                        label = { Text("Start Time") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = NeonPurple,
                            unfocusedBorderColor = SurfaceHighlight,
                            focusedContainerColor = DarkVioletElevated,
                            unfocusedContainerColor = DarkVioletElevated
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = endTime,
                        onValueChange = { endTime = it },
                        label = { Text("End Time") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = NeonPurple,
                            unfocusedBorderColor = SurfaceHighlight,
                            focusedContainerColor = DarkVioletElevated,
                            unfocusedContainerColor = DarkVioletElevated
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = room,
                    onValueChange = { room = it },
                    label = { Text("Location / Room") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonPurple,
                        unfocusedBorderColor = SurfaceHighlight,
                        focusedContainerColor = DarkVioletElevated,
                        unfocusedContainerColor = DarkVioletElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = instructor,
                    onValueChange = { instructor = it },
                    label = { Text("Instructor / Notes (Optional)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonPurple,
                        unfocusedBorderColor = SurfaceHighlight,
                        focusedContainerColor = DarkVioletElevated,
                        unfocusedContainerColor = DarkVioletElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (subjectName.isNotBlank()) {
                                onAdd(day, startTime, endTime, subjectName, room, instructor, slotType)
                                onDismiss()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("submit_slot_button")
                    ) {
                        Text("Add to Schedule", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AddAssignmentDialog(
    onAdd: (String, String, String, Priority, String) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var subjectName by remember { mutableStateOf(Subject.DefaultSubjects.first().name) }
    var dueDate by remember { mutableStateOf("Tomorrow, 11:59 PM") }
    var priority by remember { mutableStateOf(Priority.HIGH) }
    var notes by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .testTag("add_assignment_dialog"),
            color = DarkVioletSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "New Homework / Task",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Assignment Title") },
                    placeholder = { Text("e.g. Physics Problem Set #3") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonPurple,
                        unfocusedBorderColor = SurfaceHighlight,
                        focusedContainerColor = DarkVioletElevated,
                        unfocusedContainerColor = DarkVioletElevated
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("assignment_title_input")
                )

                Text("Subject", color = TextSecondary, fontSize = 12.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Subject.DefaultSubjects.take(3).forEach { sub ->
                        val isSel = subjectName == sub.name
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { subjectName = sub.name },
                            color = if (isSel) sub.color.copy(alpha = 0.3f) else DarkVioletElevated,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSel) sub.color else Color.Transparent
                            )
                        ) {
                            Text(
                                text = sub.name,
                                color = if (isSel) Color.White else TextSecondary,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = dueDate,
                    onValueChange = { dueDate = it },
                    label = { Text("Due Date / Time") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonPurple,
                        unfocusedBorderColor = SurfaceHighlight,
                        focusedContainerColor = DarkVioletElevated,
                        unfocusedContainerColor = DarkVioletElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Priority Level", color = TextSecondary, fontSize = 12.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Priority.values().forEach { prio ->
                        val isSel = priority == prio
                        val color = when (prio) {
                            Priority.HIGH -> CoralPink
                            Priority.MEDIUM -> AmberWarning
                            Priority.LOW -> CyanAccent
                        }
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { priority = prio },
                            color = if (isSel) color.copy(alpha = 0.25f) else DarkVioletElevated,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSel) color else Color.Transparent
                            )
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = prio.label,
                                    color = if (isSel) color else TextSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Instructions / Requirements") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonPurple,
                        unfocusedBorderColor = SurfaceHighlight,
                        focusedContainerColor = DarkVioletElevated,
                        unfocusedContainerColor = DarkVioletElevated
                    ),
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                onAdd(title, subjectName, dueDate, priority, notes)
                                onDismiss()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("submit_assignment_button")
                    ) {
                        Text("Add Assignment", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AddNoteDialog(
    initialTitle: String = "",
    initialSubject: String = Subject.DefaultSubjects.first().name,
    initialContent: String = "",
    onSave: (String, String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(initialTitle) }
    var subjectName by remember { mutableStateOf(initialSubject) }
    var content by remember { mutableStateOf(initialContent) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .testTag("note_dialog"),
            color = DarkVioletSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = if (initialTitle.isEmpty()) "Create Subject Note" else "Edit Note",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Note Title") },
                    placeholder = { Text("e.g. Organic Chemistry Reactions") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonPurple,
                        unfocusedBorderColor = SurfaceHighlight,
                        focusedContainerColor = DarkVioletElevated,
                        unfocusedContainerColor = DarkVioletElevated
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("note_title_input")
                )

                Text("Subject", color = TextSecondary, fontSize = 12.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Subject.DefaultSubjects.take(3).forEach { sub ->
                        val isSel = subjectName == sub.name
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { subjectName = sub.name },
                            color = if (isSel) sub.color.copy(alpha = 0.3f) else DarkVioletElevated,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSel) sub.color else Color.Transparent
                            )
                        ) {
                            Text(
                                text = sub.name,
                                color = if (isSel) Color.White else TextSecondary,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                // Quick formatting chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FormatHelperChip(label = "+ Bullet") { content += "\n• " }
                    FormatHelperChip(label = "+ Checklist") { content += "\n[ ] " }
                    FormatHelperChip(label = "+ Key Formula") { content += "\nFormula: " }
                }

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Note Content") },
                    minLines = 5,
                    maxLines = 10,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonPurple,
                        unfocusedBorderColor = SurfaceHighlight,
                        focusedContainerColor = DarkVioletElevated,
                        unfocusedContainerColor = DarkVioletElevated
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("note_content_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                onSave(title, subjectName, content)
                                onDismiss()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("submit_note_button")
                    ) {
                        Text("Save Note", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun FormatHelperChip(
    label: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .clickable(onClick = onClick),
        color = DarkVioletElevated,
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceHighlight)
    ) {
        Text(
            text = label,
            color = VividAmethyst,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun AddQuizQuestionDialog(
    initialSubject: String,
    onAdd: (String, String, String, String, String, String, Int, String) -> Unit,
    onDismiss: () -> Unit
) {
    var subjectName by remember { mutableStateOf(initialSubject) }
    var question by remember { mutableStateOf("") }
    var optA by remember { mutableStateOf("") }
    var optB by remember { mutableStateOf("") }
    var optC by remember { mutableStateOf("") }
    var optD by remember { mutableStateOf("") }
    var correctIndex by remember { mutableStateOf(0) }
    var explanation by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .testTag("add_quiz_dialog"),
            color = DarkVioletSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Create Practice Question",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = question,
                    onValueChange = { question = it },
                    label = { Text("Question Prompt") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonPurple,
                        unfocusedBorderColor = SurfaceHighlight,
                        focusedContainerColor = DarkVioletElevated,
                        unfocusedContainerColor = DarkVioletElevated
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("quiz_question_input")
                )

                OutlinedTextField(
                    value = optA,
                    onValueChange = { optA = it },
                    label = { Text("Option A") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonPurple,
                        unfocusedBorderColor = SurfaceHighlight,
                        focusedContainerColor = DarkVioletElevated,
                        unfocusedContainerColor = DarkVioletElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = optB,
                    onValueChange = { optB = it },
                    label = { Text("Option B") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonPurple,
                        unfocusedBorderColor = SurfaceHighlight,
                        focusedContainerColor = DarkVioletElevated,
                        unfocusedContainerColor = DarkVioletElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = optC,
                    onValueChange = { optC = it },
                    label = { Text("Option C") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonPurple,
                        unfocusedBorderColor = SurfaceHighlight,
                        focusedContainerColor = DarkVioletElevated,
                        unfocusedContainerColor = DarkVioletElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = optD,
                    onValueChange = { optD = it },
                    label = { Text("Option D") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonPurple,
                        unfocusedBorderColor = SurfaceHighlight,
                        focusedContainerColor = DarkVioletElevated,
                        unfocusedContainerColor = DarkVioletElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Which is the correct answer?", color = TextSecondary, fontSize = 12.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("A", "B", "C", "D").forEachIndexed { idx, letter ->
                        val isSel = correctIndex == idx
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { correctIndex = idx },
                            color = if (isSel) MintGreen.copy(alpha = 0.25f) else DarkVioletElevated,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSel) MintGreen else Color.Transparent
                            )
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = letter,
                                    color = if (isSel) MintGreen else TextSecondary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = explanation,
                    onValueChange = { explanation = it },
                    label = { Text("Explanation (Optional)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonPurple,
                        unfocusedBorderColor = SurfaceHighlight,
                        focusedContainerColor = DarkVioletElevated,
                        unfocusedContainerColor = DarkVioletElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (question.isNotBlank() && optA.isNotBlank() && optB.isNotBlank()) {
                                onAdd(subjectName, question, optA, optB, optC.ifBlank { "N/A" }, optD.ifBlank { "N/A" }, correctIndex, explanation)
                                onDismiss()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("submit_quiz_question_button")
                    ) {
                        Text("Save Question", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
